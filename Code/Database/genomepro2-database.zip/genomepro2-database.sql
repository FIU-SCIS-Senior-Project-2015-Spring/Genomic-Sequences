--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: website; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA website;


ALTER SCHEMA website OWNER TO postgres;

SET search_path = website, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: files; Type: TABLE; Schema: website; Owner: postgres; Tablespace: 
--

CREATE TABLE files (
    file_id integer NOT NULL,
    type_id integer NOT NULL,
    user_id integer NOT NULL,
    path character(100) NOT NULL,
    name character(100) NOT NULL
);


ALTER TABLE website.files OWNER TO postgres;

--
-- Name: files_file_id_seq; Type: SEQUENCE; Schema: website; Owner: postgres
--

CREATE SEQUENCE files_file_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE website.files_file_id_seq OWNER TO postgres;

--
-- Name: files_file_id_seq; Type: SEQUENCE OWNED BY; Schema: website; Owner: postgres
--

ALTER SEQUENCE files_file_id_seq OWNED BY files.file_id;


--
-- Name: involves; Type: TABLE; Schema: website; Owner: postgres; Tablespace: 
--

CREATE TABLE involves (
    job_id integer NOT NULL,
    file_id integer NOT NULL
);


ALTER TABLE website.involves OWNER TO postgres;

--
-- Name: jobs; Type: TABLE; Schema: website; Owner: postgres; Tablespace: 
--

CREATE TABLE jobs (
    job_id integer NOT NULL,
    user_id integer NOT NULL,
    tool_id integer NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL,
    results character(100),
    args character(100),
    visible boolean DEFAULT true,
    start smallint DEFAULT 1 NOT NULL,
    finish smallint DEFAULT 1 NOT NULL
);


ALTER TABLE website.jobs OWNER TO postgres;

--
-- Name: COLUMN jobs.visible; Type: COMMENT; Schema: website; Owner: postgres
--

COMMENT ON COLUMN jobs.visible IS 'visible in the history of the user';


--
-- Name: COLUMN jobs.start; Type: COMMENT; Schema: website; Owner: postgres
--

COMMENT ON COLUMN jobs.start IS 'for chaining jobs';


--
-- Name: jobs_job_id_seq; Type: SEQUENCE; Schema: website; Owner: postgres
--

CREATE SEQUENCE jobs_job_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE website.jobs_job_id_seq OWNER TO postgres;

--
-- Name: jobs_job_id_seq; Type: SEQUENCE OWNED BY; Schema: website; Owner: postgres
--

ALTER SEQUENCE jobs_job_id_seq OWNED BY jobs.job_id;


--
-- Name: steps; Type: TABLE; Schema: website; Owner: postgres; Tablespace: 
--

CREATE TABLE steps (
    tool_id integer NOT NULL,
    step integer NOT NULL,
    next integer NOT NULL
);


ALTER TABLE website.steps OWNER TO postgres;

--
-- Name: tools; Type: TABLE; Schema: website; Owner: postgres; Tablespace: 
--

CREATE TABLE tools (
    tool_id integer NOT NULL,
    name character(50) NOT NULL,
    description text NOT NULL,
    type smallint NOT NULL,
    exe_path character(100) NOT NULL,
    visible boolean DEFAULT true NOT NULL
);


ALTER TABLE website.tools OWNER TO postgres;

--
-- Name: COLUMN tools.tool_id; Type: COMMENT; Schema: website; Owner: postgres
--

COMMENT ON COLUMN tools.tool_id IS 'WARNING: changing this will break a tool if not modified at the tools controller and job processor!!';


--
-- Name: COLUMN tools.type; Type: COMMENT; Schema: website; Owner: postgres
--

COMMENT ON COLUMN tools.type IS '1: job takes one file as input, 2: multiple';


--
-- Name: COLUMN tools.visible; Type: COMMENT; Schema: website; Owner: postgres
--

COMMENT ON COLUMN tools.visible IS 'visible as a tool or hidden';


--
-- Name: tools_tool_id_seq; Type: SEQUENCE; Schema: website; Owner: postgres
--

CREATE SEQUENCE tools_tool_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE website.tools_tool_id_seq OWNER TO postgres;

--
-- Name: tools_tool_id_seq; Type: SEQUENCE OWNED BY; Schema: website; Owner: postgres
--

ALTER SEQUENCE tools_tool_id_seq OWNED BY tools.tool_id;


--
-- Name: types; Type: TABLE; Schema: website; Owner: postgres; Tablespace: 
--

CREATE TABLE types (
    type_id integer NOT NULL,
    name character(50) NOT NULL,
    description text NOT NULL
);


ALTER TABLE website.types OWNER TO postgres;

--
-- Name: types_type_id_seq; Type: SEQUENCE; Schema: website; Owner: postgres
--

CREATE SEQUENCE types_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE website.types_type_id_seq OWNER TO postgres;

--
-- Name: types_type_id_seq; Type: SEQUENCE OWNED BY; Schema: website; Owner: postgres
--

ALTER SEQUENCE types_type_id_seq OWNED BY types.type_id;


--
-- Name: users; Type: TABLE; Schema: website; Owner: postgres; Tablespace: 
--

CREATE TABLE users (
    user_id integer NOT NULL,
    username character(30) NOT NULL,
    password character(40) NOT NULL,
    email character(260) NOT NULL,
    type smallint NOT NULL,
    about text NOT NULL,
    avatar character(100) NOT NULL,
    serial character(40),
    firstname character(25),
    lastname character(25),
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL,
    ftp character(100) NOT NULL,
    temp character(40)
);


ALTER TABLE website.users OWNER TO postgres;

--
-- Name: COLUMN users.user_id; Type: COMMENT; Schema: website; Owner: postgres
--

COMMENT ON COLUMN users.user_id IS 'automatically generated';


--
-- Name: COLUMN users.type; Type: COMMENT; Schema: website; Owner: postgres
--

COMMENT ON COLUMN users.type IS '0 - unregistered; 1 - user; 2 - admin';


--
-- Name: COLUMN users.serial; Type: COMMENT; Schema: website; Owner: postgres
--

COMMENT ON COLUMN users.serial IS 'confirmation link for email';


--
-- Name: COLUMN users."timestamp"; Type: COMMENT; Schema: website; Owner: postgres
--

COMMENT ON COLUMN users."timestamp" IS 'time when user registered';


--
-- Name: COLUMN users.ftp; Type: COMMENT; Schema: website; Owner: postgres
--

COMMENT ON COLUMN users.ftp IS 'ftp generated username and password';


--
-- Name: COLUMN users.temp; Type: COMMENT; Schema: website; Owner: postgres
--

COMMENT ON COLUMN users.temp IS 'a temporary password for recovery of account';


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: website; Owner: postgres
--

CREATE SEQUENCE users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE website.users_user_id_seq OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: website; Owner: postgres
--

ALTER SEQUENCE users_user_id_seq OWNED BY users.user_id;


--
-- Name: file_id; Type: DEFAULT; Schema: website; Owner: postgres
--

ALTER TABLE ONLY files ALTER COLUMN file_id SET DEFAULT nextval('files_file_id_seq'::regclass);


--
-- Name: job_id; Type: DEFAULT; Schema: website; Owner: postgres
--

ALTER TABLE ONLY jobs ALTER COLUMN job_id SET DEFAULT nextval('jobs_job_id_seq'::regclass);


--
-- Name: tool_id; Type: DEFAULT; Schema: website; Owner: postgres
--

ALTER TABLE ONLY tools ALTER COLUMN tool_id SET DEFAULT nextval('tools_tool_id_seq'::regclass);


--
-- Name: type_id; Type: DEFAULT; Schema: website; Owner: postgres
--

ALTER TABLE ONLY types ALTER COLUMN type_id SET DEFAULT nextval('types_type_id_seq'::regclass);


--
-- Name: user_id; Type: DEFAULT; Schema: website; Owner: postgres
--

ALTER TABLE ONLY users ALTER COLUMN user_id SET DEFAULT nextval('users_user_id_seq'::regclass);


--
-- Name: files_pkey; Type: CONSTRAINT; Schema: website; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY files
    ADD CONSTRAINT files_pkey PRIMARY KEY (file_id);


--
-- Name: jobs_pkey; Type: CONSTRAINT; Schema: website; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (job_id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: website; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- PostgreSQL database dump complete
--

